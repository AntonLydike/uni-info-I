 1. `int * p;` (oder `int * p = NULL;`)
 2. `double * q = &x;`
 3. `char * r = w+sizeof(char);`
 4. `'i'`
 5. `*w = 'c';`
