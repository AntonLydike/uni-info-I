 1. Zähle wie oft `x` in `w` vorkommt.
 2. Gebe die ersten `n` werte aus dem int array `x` aus.
