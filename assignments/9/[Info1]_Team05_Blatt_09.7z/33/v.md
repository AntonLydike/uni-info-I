
**1.**

![](assignments/9/33/v_1.include.png)



**2.**

![](assignments/9/33/v_2.include.png)

<br/>
