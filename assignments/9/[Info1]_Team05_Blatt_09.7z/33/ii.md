 1. Gib die ersten 2 Buchstaben des Wortes "Merry" aus.
 2. Gib "er" aus.
 3. Gib die ersten 2 Buchstaben des Wortes "Merry" aus.
 4. Gib den Buchstaben 'N' ('M' + 1), gefolgt von 'O' ('N' + 1) aus.
 5. Gib das Wort "Merry" ab dem zweiten Buchstaben aus.
