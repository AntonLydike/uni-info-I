Das Programm erwartet eine Tastatureingabe und gibt je nach eingabe den Preis
für eine Kategorie aus, oder beendet Das Programm. Folgende Optionen sind
vorhanden:

 - 'a' für Kinder (5.00),
 - 'b' für Erwachsene (9.50),
 - 'c' für Studenten (7.50) und
 - 'q' um das Programm zu beenden

Nach ungültiger Eingabe wird darauf hingewiesen und dann die nächste Eingabe
erwartet. Nach erfolgreicher Eingabe wird der Preis ausgegeben und dann auf die
nächste Eingabe gewartet.
