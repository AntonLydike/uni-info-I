double calc_arithmetic_mean(int a, int b)
