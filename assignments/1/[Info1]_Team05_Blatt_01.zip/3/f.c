#include <stdio.h>

int main(int argc, char * argv[])
{
	printf("Programmname: %s\nArgument 1:   %s\nArgument 2:   %s\n",
	       argv[0],
	       argv[1],
	       argv[2]
	       );

	return 0;
}
