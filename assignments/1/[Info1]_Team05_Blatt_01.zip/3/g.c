#include <stdio.h>

int main(void)
{
	int input;

	printf("Bitte geben Sie eine Zahl ein: ");

	scanf("%d", &input);

	printf("Sie haben %d eingegeben\n", input);

	return 0;
}
