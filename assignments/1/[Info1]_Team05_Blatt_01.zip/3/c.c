#include <stdio.h>

int main(int argc, char * argv[])
{
	printf("Anzahl der Parameter:%d\nProgrammname:%s\n", argc - 1, argv[0]);

	return 0;
}
