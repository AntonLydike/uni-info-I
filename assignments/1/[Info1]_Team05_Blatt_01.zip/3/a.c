#include <stdio.h>

int main(void)
{
	printf("line\n\n");
	
	return 0;
}
