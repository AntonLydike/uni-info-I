#include <stdio.h>

int main(void)
{
        printf("%%\\\\n\n");
        
        return 0;
}
