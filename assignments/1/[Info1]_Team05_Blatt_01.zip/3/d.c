#include <stdio.h>

int main(int argc, char * argv[])
{
	printf("Vierfaches der anzahl der Parameter:%d\n", (argc - 1) * 4);

	return 0;
}
