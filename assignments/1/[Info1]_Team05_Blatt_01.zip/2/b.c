#include <stdio.h>

int main(void)
{
	printf("Hallo\n");
	return 0;
}

/* Ausgabe: Hallo */
