#include <stdio.h>

int main(void)
{
	char d = 'a';

	printf("%c\n", d);
	return 0;
}

/* Ausgabe: a */
