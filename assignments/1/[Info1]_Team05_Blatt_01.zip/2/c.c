#include <stdio.h>

int main(void)
{
	double d = 5.50;

	printf("%.2f\n", d);
	return 0;
}

/* Ausgabe: 5.50 */
