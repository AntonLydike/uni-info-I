 1. `int endswith(char *string, char end);`
 2. `double average(int field[], int length);`
