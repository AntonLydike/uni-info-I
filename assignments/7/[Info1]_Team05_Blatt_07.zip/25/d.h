/* 25/d.h  */
#ifndef GETSIGN_INCLUDED
#define GETSIGN_INCLUDED

#define getsign(num) ((num) >= 0 ? 1 : -1)

#endif
