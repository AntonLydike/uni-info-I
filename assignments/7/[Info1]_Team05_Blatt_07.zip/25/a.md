  1. `#define FALSE 0`
  2. `#define mittelwert(a, b) (((a) + (b))/2)`
  3. `#define print_terminated() printf("Program terminated")`
  4. `#define toupper(c) (((c) >= 'a' && (c) <= 'z') ? (c) + 32 : (c))`
