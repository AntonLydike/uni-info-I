#include <stdlib.h>
#include <stdio.h>

int matrix_create(int ***m, int ze, int sp)
{
	int i, k;

	*m = malloc(ze * sizeof(int*));
	if (!(*m))
		return 0;

	for (i = 0; i < ze; i++) {
		(*m)[i] = malloc(sp * sizeof(int));
		if (!(*m)[i]) {
			for (k = 0; k < i; ++k)
				free((*m)[k]);
			free(*m);
			return 0;
		}
	}

	return 1;
}

int main (void) {
        int **m, i, j;

        if (!matrix_create(&m, 5, 5)) {
                printf("Error.\n");
                return 0;
        }

        for (i=0; i<5;i++) {
                for (j=0;j<5;j++) {
                        printf("%i ", m[i][j]);
                }
                printf("\n");
        }

        return 0;
}
