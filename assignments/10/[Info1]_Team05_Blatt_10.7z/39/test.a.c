#include <stdio.h>
#include <stdlib.h>

int matrix_create(int ***m, int ze, int sp)
{
	int i, k;

	*m = malloc(ze * sizeof(int*));
	if (!(*m))
		return 0;

	for (i = 0; i < ze; i++) {
		(*m)[i] = malloc(sp * sizeof(int));
		if (!(*m)[i]) {
			for (k = 0; k < i; ++k)
				free((*m)[k]);
			free(*m);
			return 0;
		}
	}

	return 1;
}

int **matrix_cpy_deep(int **m, int ze, int sp)
{
        int **n, i, k;

        n = malloc(ze * sizeof(int*));
        if (!n)
                return 0;

        for (i = 0; i < ze; i++) {
                n[i] = malloc(sp * sizeof(int));
                if (!n[i]) {
                        for (k = 0; k < i; k++)
                                free(n[k]);

                        free(n);
                        return NULL;
                }
                for (k = 0; k < sp; k++) {
                        n[i][k] = m[i][k];
                }
        }

        return n;
}

void print_matrix(int **m, int k, int l) {
        int i, j;

        for (i=0; i<k;i++) {
                for (j=0;j<l;j++) {
                        printf("%4i ", m[i][j]);
                }
                printf("\n");
        }
        printf("########################\n");
}

int main (void) {
        int **m, **n, i, j;

        if (!matrix_create(&m, 5, 5)) {
                printf("Error.\n");
                return 0;
        }

        m[1][1] = 14;
        m[1][4] = 33;
        m[0][2] = 88;
        m[4][4] = 17;
        m[0][0] = 1;

        print_matrix(m, 5, 5);

        n = matrix_cpy_deep(m, 5, 5);

        print_matrix(m, 5, 5);
        print_matrix(n, 5, 5);

        return 0;
}
