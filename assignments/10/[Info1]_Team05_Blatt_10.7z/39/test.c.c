#include <stdio.h>
#include <stdlib.h>

void stringlist_swap(char *list[], int i, int j)
{
        char * tmp = list[i];
        list[i] = list[j];
        list[j] = tmp;
}


int main (void) {
        char ** ts;
        char t1[] = "abcd";
        char t2[] = "bbbb";

        ts = malloc(2 * sizeof(char *));

        ts[0] = t1;
        ts[1] = t2;

        printf("%s, %s\n", ts[0], ts[1]);

        stringlist_swap(ts, 0, 1);

        printf("%s, %s\n", ts[0], ts[1]);

        return 0;
}
